create view position(account_id, ticker, position) as
SELECT security_order.account_id,
       security_order.ticker,
       sum(security_order.size) AS "position"
FROM security_order
WHERE security_order.status::text = 'FILLED'::text
GROUP BY security_order.account_id, security_order.ticker;

alter table position
    owner to postgres;

